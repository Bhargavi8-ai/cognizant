# Bootstrap 5 Learning Exercises

A comprehensive collection of hands-on Bootstrap 5 exercises covering responsive design, grid systems, components, and flexbox utilities.

## 📁 Project Structure

```
Bootstrap-Exercises/
├── index.html                 (Main navigation page)
├── package.json              (Project metadata)
├── exercise1/                (Basics - CDN & Setup)
│   ├── 1.1-basic-html.html          (Bootstrap via CDN)
│   └── 1.2-npm-setup.html           (NPM Installation Guide)
├── exercise2/                (Bootstrap Structure)
│   ├── 2.1-structure.html           (Directory Structure)
│   └── 2.2-js-plugins.html          (JavaScript Plugins)
├── exercise3/                (Grid System)
│   ├── 3.1-responsive-grid.html     (Responsive 3-Column)
│   └── 3.2-grid-classes.html        (Grid Classes & Breakpoints)
├── exercise4/                (Column Layouts)
│   ├── 4.1-two-column.html          (Sidebar + Content Layout)
│   └── 4.2-four-column.html         (Equal Width Product Grid)
├── exercise5/                (Alignment & Reordering)
│   ├── 5.1-alignment.html           (Centering & Alignment)
│   └── 5.2-reordering.html          (Column Reordering)
├── exercise7/                (Flexbox Utilities)
│   ├── 7.1-navbar.html              (Responsive Navigation)
│   └── 7.2-card-layout.html         (Flexible Card Layouts)
├── css/                      (Custom styles)
└── js/                       (Custom scripts)
```

## 📚 Exercises Overview

### Exercise 1: Getting Started
- **1.1**: Create a basic HTML page linked to Bootstrap 5 via CDN
- **1.2**: Set up a project using npm with Bootstrap files

### Exercise 2: Bootstrap Structure
- **2.1**: Explore Bootstrap's directory structure (CSS, JS, icons folders)
- **2.2**: Include Bootstrap JavaScript plugins via bootstrap.bundle.min.js

### Exercise 3: Responsive Grid Layout
- **3.1**: 3-column layout that stacks on mobile, 2-per-row on tablet, 3-per-row on desktop
- **3.2**: Understanding container, row, and col-* classes for responsive design

### Exercise 4: Column Layouts
- **4.1**: Two-column layout with sidebar (col-md-3) and content area (col-md-9)
- **4.2**: Four-column layout with equal width (col-sm-3) elements

### Exercise 5: Alignment & Reordering
- **5.1**: Use justify-content-center and align-items-center for centering
- **5.2**: Reorder columns on different screen sizes using order-md-* classes

### Exercise 7: Responsive Flexbox
- **7.1**: Build a navbar using d-flex and flex-md-row for responsive behavior
- **7.2**: Create card layouts with justify-content-between and align-items-center

## 🚀 Getting Started

### Option 1: Using Bootstrap CDN (Recommended for Learning)
Simply open any HTML file directly in your browser. No installation needed!

### Option 2: Using NPM

1. **Initialize the project** (if not already done):
   ```bash
   npm init -y
   ```

2. **Install Bootstrap**:
   ```bash
   npm install bootstrap
   ```

3. **Import Bootstrap in your files**:
   ```javascript
   import 'bootstrap/dist/css/bootstrap.min.css';
   import bootstrap from 'bootstrap';
   ```

4. **Run a local server**:
   ```bash
   npx http-server
   ```
   or
   ```bash
   npm install -g live-server
   live-server
   ```

## 📖 Key Bootstrap Concepts

### Breakpoints
- **Extra small** (< 576px) - Mobile
- **Small** (≥ 576px) - sm
- **Medium** (≥ 768px) - md
- **Large** (≥ 992px) - lg
- **Extra large** (≥ 1200px) - xl
- **XXL** (≥ 1400px) - xxl

### Grid System
- Uses 12-column layout
- Classes: `col-*`, `col-sm-*`, `col-md-*`, `col-lg-*`, etc.
- Example: `col-md-6` = 50% width on medium screens and up

### Flexbox Utilities
- `d-flex` - Display flex
- `justify-content-center` - Horizontal centering
- `align-items-center` - Vertical centering
- `justify-content-between` - Space between items
- `flex-grow-1` - Fill available space
- `gap-*` - Spacing between flex items

### Common Classes
- `.container` - Fixed width container
- `.container-fluid` - Full width
- `.row` - Flex row wrapper
- `.col` - Flex column
- `.btn` - Button styling
- `.card` - Card component
- `.alert` - Alert messages
- `.navbar` - Navigation bar

## 💡 Tips for Learning

1. **Inspect Elements**: Use browser DevTools to inspect CSS classes applied
2. **Responsive Testing**: Resize your browser or use DevTools device emulation
3. **Experiment**: Modify HTML classes to see how Bootstrap responds
4. **Read Documentation**: Visit [Bootstrap Docs](https://getbootstrap.com/docs/)
5. **Practice**: Create your own layouts combining these patterns

## 🎯 Exercise Progression

Start from the beginning:
1. Exercise 1.1 → 1.2 (Setup)
2. Exercise 2.1 → 2.2 (Structure)
3. Exercise 3.1 → 3.2 (Grid)
4. Exercise 4.1 → 4.2 (Layouts)
5. Exercise 5.1 → 5.2 (Alignment)
6. Exercise 7.1 → 7.2 (Flexbox)

## 📝 Notes

- All exercises use Bootstrap 5.3.0 from CDN
- HTML pages are self-contained (no external CSS/JS needed except Bootstrap)
- Responsive design tested on all major screen sizes
- Each exercise includes code examples and explanations

## 🔗 Useful Resources

- [Bootstrap Official Docs](https://getbootstrap.com/docs/)
- [Bootstrap Grid System](https://getbootstrap.com/docs/5.3/layout/grid/)
- [Bootstrap Utilities](https://getbootstrap.com/docs/5.3/utilities/)
- [MDN Flexbox Guide](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Flexible_Box_Layout)

## 📦 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

---

**Happy Learning!** 🎉

For more exercises or updates, visit the official Bootstrap documentation at getbootstrap.com
